package NSeleniumDeloitteDemoPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class NSettingSystemProperty {
	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver", "C://Software Testing//JavaT2//chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.makemytrip.com");
		
		//maximize window
		driver.manage().window().maximize();
		//finding the element using the locator
		
		
		driver.findElement(By.cssSelector("#SW > div.landingContainer > div.makeFlex.hrtlCenter.prependTop5.appendBottom40 > ul > li.makeFlex.hrtlCenter.font10.makeRelative.lhUser")).click();
		driver.findElement(By.xpath("//*[@id=\"username\"]")).sendKeys("nandhuamirbala@gmail.com");
		driver.findElement(By.cssSelector(".modalLogin")).click();			 
		driver.findElement(By.cssSelector("button")).click();
		
}
}
